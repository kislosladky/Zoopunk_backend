package zoopunk.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoopunkBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoopunkBackendApplication.class, args);
	}

}
